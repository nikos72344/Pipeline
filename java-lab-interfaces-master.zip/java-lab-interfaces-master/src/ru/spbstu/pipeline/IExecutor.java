package ru.spbstu.pipeline;

public interface IExecutor extends IConfigurable, IPipelineStep {
}
