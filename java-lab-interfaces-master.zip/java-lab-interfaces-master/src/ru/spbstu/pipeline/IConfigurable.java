package ru.spbstu.pipeline;

public interface IConfigurable {
	RC setConfig(String configFileName);
}
