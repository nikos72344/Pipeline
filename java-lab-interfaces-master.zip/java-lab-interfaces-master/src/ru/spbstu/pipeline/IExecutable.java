package ru.spbstu.pipeline;

public interface IExecutable {
	RC execute(byte [] data);
}
